package io.mac.test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import io.mac.controller.ApiController;
import io.mac.model.Country;
import io.mac.service.ContinentService;

public class ContinentServiceTest {

	@InjectMocks
	ApiController apiController;
	
	@Mock
	ContinentService cs;
	@Mock
	Country country;
	 @Before
	 public void setUp()
	 {
		 MockitoAnnotations.initMocks(this);
	 }
	 
	 @Test
	 public void getAllTest()
	 {
		 
		 
	 }
	 
	 @Test
	 public void getCountryFlagTest()
	 {
		 
		  
		 
	 }
	 
	 @Test
	 public void getContinentTest()
	 {
		 
	 }
	
	
	
	
}
