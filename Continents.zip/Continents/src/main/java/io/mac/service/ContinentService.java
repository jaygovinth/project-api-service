package io.mac.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import io.mac.model.Country;

@Service
public class ContinentService {

	HashMap<String, ArrayList<Country>> countries = new HashMap<String, ArrayList<Country>>();
	ArrayList<Country> asiaList = new ArrayList<Country>();
	ArrayList<Country> americaList = new ArrayList<Country>();
	ArrayList<Country> africaList = new ArrayList<Country>();
	ArrayList<Country> europeList = new ArrayList<Country>();
	ArrayList<Country> oceaniaList = new ArrayList<Country>();
	
	 
 
	 
	

	public ContinentService() {

		Country country = new Country();
		// Africa
		country.setCountryName("Nigeria");
		country.setFlag("NR");
		africaList.add(country);

		country = new Country();
		country.setCountryName("Ethiopia");
		country.setFlag("ET");
		africaList.add(country);

		country = new Country();
		country.setCountryName("Egypt");
		country.setFlag("EG");
		africaList.add(country);

		country = new Country();
		country.setCountryName("DR Congo");
		country.setFlag("CD");
		africaList.add(country);

		country = new Country();
		country.setCountryName("South Africa");
		country.setFlag("ZA");
		africaList.add(country);

		country = new Country();
		country.setCountryName("South Africa");
		country.setFlag("ZA");
		africaList.add(country);

		countries.put("Africa".toLowerCase(), africaList);

		// America
		country = new Country();
		country.setCountryName("USA");
		country.setFlag("US");
		americaList.add(country);

		country = new Country();
		country.setCountryName("Brazil");
		country.setFlag("BR");
		americaList.add(country);

		country = new Country();
		country.setCountryName("Mexico");
		country.setFlag("MX");
		americaList.add(country);

		country = new Country();
		country.setCountryName("Columbia");
		country.setFlag("CO");
		americaList.add(country);

		country = new Country();
		country.setCountryName("Argentina");
		country.setFlag("AR");
		americaList.add(country);
		countries.put("America".toLowerCase(), americaList);

		// ASIA
		country = new Country();
		country.setCountryName("China");
		country.setFlag("CN");
		asiaList.add(country);
		
		country = new Country();
		country.setCountryName("India");
		country.setFlag("IN");
		asiaList.add(country);

		country = new Country();
		country.setCountryName("Indonesia");
		country.setFlag("ID");
		asiaList.add(country);

		country = new Country();
		country.setCountryName("Pakistan");
		country.setFlag("PK");
		asiaList.add(country);

		country = new Country();
		country.setCountryName("Bangladesh");
		country.setFlag("BD");
		asiaList.add(country);
		countries.put("Asia".toLowerCase(), asiaList);

		// Europe
		country = new Country();
		country.setCountryName("Russia");
		country.setFlag("RU");
		europeList.add(country);

		country = new Country();
		country.setCountryName("Germany");
		country.setFlag("DE");
		europeList.add(country);

		country = new Country();
		country.setCountryName("UK");
		country.setFlag("GB");
		europeList.add(country);

		country = new Country();
		country.setCountryName("France");
		country.setFlag("FR");
		europeList.add(country);

		country = new Country();
		country.setCountryName("Italy");
		country.setFlag("IT");
		europeList.add(country);
		countries.put("Europe".toLowerCase(), europeList);

		// Oceania
		country = new Country();
		country.setCountryName("Australia");
		country.setFlag("AU");
		oceaniaList.add(country);

		country = new Country();
		country.setCountryName("Papua New Guinea");
		country.setFlag("PG");
		oceaniaList.add(country);

		country = new Country();
		country.setCountryName("New Zealand");
		country.setFlag("NZ");
		oceaniaList.add(country);

		country = new Country();
		country.setCountryName("Fiji");
		country.setFlag("FJ");
		oceaniaList.add(country);

		country = new Country();
		country.setCountryName("Solomon Islands");
		country.setFlag("SB");
		oceaniaList.add(country);
		countries.put("Oceania".toLowerCase(), oceaniaList);

	}

	public ArrayList<Country> getContinent(String continentName) {
		if (countries.containsKey(continentName)) {
			return countries.get(continentName);
		} else {
			return null;
		}
	}

	public String getCountryFlag(String countryName) {

		String flag = "";

		for (Country country : asiaList) {
			if (country.getCountryName().equalsIgnoreCase(countryName))
				flag = country.getFlag();
		}
		if(flag.isEmpty())
			for (Country country : americaList) {
				if (country.getCountryName().equalsIgnoreCase(countryName))
					flag = country.getFlag();
			}
		if(flag.isEmpty())
			for (Country country : africaList) {
				if (country.getCountryName().equalsIgnoreCase(countryName))
					flag = country.getFlag();
			}
		if(flag.isEmpty())
			for (Country country : oceaniaList) {
				if (country.getCountryName().equalsIgnoreCase(countryName))
					flag = country.getFlag();
			}
		if(flag.isEmpty())
			for (Country country : europeList) {
				if (country.getCountryName().equalsIgnoreCase(countryName))
					flag = country.getFlag();
			}
		
		if (!flag.isEmpty())
			
			
			return flag;
		else
			return null;

	}

	public HashMap<String, ArrayList<Country>> getAll() {
		return countries;
	}
}
