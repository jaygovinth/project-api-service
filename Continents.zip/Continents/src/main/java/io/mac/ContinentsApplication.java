package io.mac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContinentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContinentsApplication.class, args);
	}
}
