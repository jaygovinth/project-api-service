package io.mac.model;

import java.util.ArrayList;
import java.util.List;

public class Continent {

	String continentName;
	List<Country> list = new ArrayList<>();
	
	public String getContinentName() {
		return continentName;
	}
	public void setContinentName(String continentName) {
		this.continentName = continentName;
	}
	public List<Country> getList() {
		return list;
	}
	public void setList(List<Country> list) {
		this.list = list;
	}

	 
	
}
