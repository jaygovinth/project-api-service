package io.mac.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.mac.model.Country;
import io.mac.service.ContinentService;

 

@RequestMapping("/atlas")
@RestController
public class ApiController {

	@Autowired
	ContinentService cs;
	
	@RequestMapping("/all")
	public HashMap<String, ArrayList<Country>>getAll(){
		return cs.getAll();
	}
	
	@RequestMapping("/continent/{continent}")
	public ArrayList<Country> getCountries(@PathVariable("continent") String continentName)
	{
		return cs.getContinent(continentName.toLowerCase());
	}
	
	@RequestMapping("/country/{country}")
	public Map getFlag(@PathVariable("country") String countryName)
	{
		 return Collections.singletonMap("flag",cs.getCountryFlag(countryName) );
		//return cs.getCountryFlag(countryName);
	}
	
}